<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from hostelgirl.info/49pay.php?web=sex2&pay=&roz= by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 20:03:41 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <style>

/* ---------- BODY ---------- */
body {
  margin: 0;
  padding: 0;
  background: #f4f6f9;
  font-family: Arial, sans-serif;
}

/* ---------- CONTAINER ---------- */
.container {
  max-width: 450px;
  background: #ffffff;
  padding: 15px;
  border-radius: 15px;
  margin-top: 10px;
  box-shadow: 0 0 15px rgba(0,0,0,0.1);
}

/* ---------- IMAGE ---------- */
#popup_image {
  width: 95%;
  height: auto;
  border-radius: 15px;
  border: 3px solid #e0e0e0;
}

/* ---------- HEADINGS ---------- */
h4 {
  font-size: 18px !important;
  font-weight: bold;
  margin: 10px 0;
}

/* ---------- TEXT ---------- */
b {
  font-size: 18px !important;
  text-align: center !important;
  float: none !important;
  display: block;
  color: #333;
  margin: 10px 0;
}

/* ---------- INPUT FIELD ---------- */
.form-control {
  height: 50px;
  font-size: 18px;
  border-radius: 10px;
  border: 2px solid #cfcfcf;
  padding-left: 15px;
  box-shadow: none;
}

.form-control:focus {
  border-color: #28a745;
  box-shadow: 0 0 5px rgba(40,167,69,0.4);
}

/* ---------- BUTTON ---------- */
.btn-lg {
  height: 55px;
  font-size: 20px;
  font-weight: bold;
  border-radius: 12px;
  border: none;
  transition: 0.3s;
}

.btn-lg:hover {
  transform: scale(1.03);
  box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

/* ---------- GLOW BUTTON ---------- */
.button {
  animation: glowing 1500ms infinite;
  border-radius: 12px;
}

@keyframes glowing {
  0% { background-color: #28a745; box-shadow: 0 0 5px #28a745; }
  50% { background-color: #49e819; box-shadow: 0 0 20px #49e819; }
  100% { background-color: #28a745; box-shadow: 0 0 5px #28a745; }
}

/* ---------- BLINK TEXT ---------- */
.blink {
  animation: blinker 1.5s linear infinite;
  font-weight: bold;
}

@keyframes blinker {
  50% { opacity: 0; }
}

/* ---------- MOBILE OPTIMIZATION ---------- */
@media (max-width: 480px) {

  h4 {
    font-size: 16px !important;
  }

  b {
    font-size: 16px !important;
  }

  .btn-lg {
    font-size: 18px;
  }

}

</style>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
	 <link async rel="stylesheet" href="assets/css/bootstrap.min.css"/>
   <style>
	img {
	 border-radius: 20px;
	}
      .button {
        background-color: #1c87c9;
        -webkit-border-radius: 60px;
        border-radius: 60px;
        border: none;
        color: #eeeeee;
        cursor: pointer;
        display: inline-block;
        font-family: sans-serif;
        font-size: 20px;
        padding: 5px 15px;
        text-align: center;
        text-decoration: none;
      }
      @keyframes glowing {
        0% {
          background-color: #2ba805;
          box-shadow: 0 0 5px #2ba805;
        }
        50% {
          background-color: #49e819;
          box-shadow: 0 0 20px #49e819;
        }
        100% {
          background-color: #2ba805;
          box-shadow: 0 0 5px #2ba805;
        }
      }
      .button {
        animation: glowing 1300ms infinite;
      }
      
      .blink {
                animation: blinker 1.5s linear infinite;
                color: green;
                
                font-size:20px;
                font-family: sans-serif;
                font-weight: bold;
            }
            @keyframes blinker {
                50% {
                    opacity: 0;
                }
            }
			
			
			
			.modal_center {
  text-align: center;
  padding: 0!important;
}

.modal_center:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px; /* Adjusts for spacing */
}

.modal_center_dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}
.hand {
  font-size: 24px;
  position: relative;
  animation-duration: 0.5s;
  animation-timing-function: ease;
  animation-iteration-count: infinite; /* Infinite loop */
}

.left-hand {
  animation-name: moveLeftToRight;
}

.right-hand {
  animation-name: moveRightToLeft;
}

/* Keyframes for animation */
@keyframes moveLeftToRight {
  0% {
    transform: translateX(-5px);
  }
  50% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(-5px);
  }
}

@keyframes moveRightToLeft {
  0% {
    transform: translateX(5px);
  }
  50% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(5px);
  }
}
    </style>
</head>
<body>
	    <div class="container" style="margin-top:10px;">
	    <div class="row">
          <div class="col-12"  style="text-align:center"> 
			  <img src="uploads/2.gif"  id="popup_image" width="300" height="330" alt=""/> 
		</div> 
                <h4 class="mt-4 text-center blink" style="size:25px;">💋Phone sex 49 rupees only💄👄</h4>
				<h4 class="mt-4 text-center blink" style="color:blueviolet;">🟢LIVE वीडियो कॉल पर सेक्स करे!🩱💦</h4>
      
                <b style="text-align: center;
            float: left;
            font-size: 30px;
            font-family: sans-serif;color:green;"> Enter your number <br/>💦 To 🍑<br/>ᶠᶸᶜᵏme𓀐𓂸. (‿ˠ‿) </b>
          <input type="hidden" name="sendorder" id="sendorder" value="sendorder"/>
          <input type="hidden" name="amount" id="amount" value="49"/>
          <input type="hidden" name="website" id="website" value="sex2"/>
          <div class="form-group" style="display:none;">
            <label for="email">Name:</label>
            <input type="text" class="form-control" value="" id="name" name="name">
          </div>
          <div class="form-group" style="    margin-bottom: -10px;">
            <label for="pwd">Whatsapp No:</label>
            <input oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
    type = "number"
    maxlength = "10" class="form-control" id="phone" name="phone" required >
          </div>
		  
          <div class="form-group">
          <!--<button type="submit" class="btn btn-warning">Submit</button>-->
          <br/>
		  <input 
  type="button"
  class="btn btn-warning btn-lg"
  onclick="pay99()"
  value="📞 Call Now"
  style="width:100%; background-color:#008000; color:white;"
>

            </div>
          </div>
		  
      </div>
	<style>
	.loader {
    position: fixed;
    width: 100%;
    height: 100vh;
    background: #000000;
    display: none;
    left: 0;
    top: 0;
    z-index: 999999;
}

.loader img {
    width: 120px;
    margin-left: calc(50% - 60px);
    margin-top: 80px;
}

.loader h4 {
    position: fixed;
    width: 200px;
    height: 40px;
    left: 0;
    text-align: center;
    top: calc(50% - 120px);
    left: calc(50% - 100px);
    font-weight: bold;
    font-size: 30px;
    color: red;
}

.loader p:first-child {
    margin-top: 300px
}

.loader p {
    width: 95%;
    margin-left: auto;
    margin-right: auto;
    font-size: 24px;
    color: #fff;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 1px 2px #000, 1px 1px 2px #000, 1px 1px 2px #000;
}
</style>

<div class="loader">
    <img src="200w.gif">
    <p>इंतज़ार करे हम आपका संदेश भेज रहे है। सन्देश भेजे जाने पर 49 रुपए देने होंगे। भुगतान करते ही आपको <span>Sunita</span> का नंबर मिल जायेगा
    </p>
    <p>Wait, we are sending your message. You will have to pay 49 rupees after sending the message. You will get <span>Sunita</span>'s number
        once you
        make the payment.</p>
</div>	<script src="assets/whtsap/js/jquery-3.7.1.min.js"></script>
    <script src="assets/whtsap/js/sweetalert2.js"></script>

	<script async src="assets/js/bootstrap.bundle.min.js"></script>
<script>
	$(function () {
	jQuery.support.cors = true;
		$('#contactForm').on('submit', function (e) {
            e.preventDefault();
            var phone = $.trim($('#phone').val());
            var ph = /^(0|91)?[6-9][0-9]{9}$/;
           if(!phone.match(ph) || phone.length != 10)  {
                alert("Please enter 10 digit number.");
                return false;
            }
			if("true" == "true"){
				$('.loader').show();
				pay99(event, '49');
			}else{
				$('#rozer_phone').val(phone);
				$('#rozer_form').submit();
			}
        });
    });
	
    console.log("S loadedw"); 
  
function pay99() {

  var phone = document.getElementById("phone").value;

  var ph = /^(0|91)?[6-9][0-9]{9}$/;

  if(!phone.match(ph) || phone.length != 10){
    alert("Please enter valid 10 digit number");
    return;
  }

  var amount = 49;

  window.location.href =
    "recharge_me14d4.php?phone=" + encodeURIComponent(phone) +
    "&amount=" + amount;
}
</script>

         <script>
    
function saveUser(name, mobile, transaction_id) {
      // var data = JSON.stringify({
      //   name: name,
      //   mobile: mobile,
      //   transaction_id: transaction_id
      // });
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState === 4) {
          if (this.status === 200) {
            var response = JSON.parse(this.responseText);
            console.log("Success:", response);
          } else {
            console.error("Error:", this.status, this.responseText);
          }
        }
      };
      xhttp.open("GET", `saveUser.php?name=${name}&mobile=${mobile}&transaction_id=${transaction_id}`, true);
      xhttp.send();
    }
	if (window.history && window.history.pushState) {
        window.history.pushState('', null);
        $(window).on('popstate', function() {
			 document.location.href = "49paye2fa.php?web=sex2&amp;pay=&amp;roz=";
        });
    }
	function callApi(id) {
    const apiUrl = `https://sweetmeets.in/flirt/api.php?id=${id}`; // replace with your API URL

    fetch(apiUrl, {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log("✅ Success! Redirecting...");
            window.location.href = "thankyou1.html"; // 🔀 Redirect if success
        } else {
            console.warn("Retrying in 5 seconds... Reason:", data.message);
            setTimeout(() => callApi(id), 1000); // ⏳ Retry after 5 sec
        }
    })
    .catch(error => {
        console.error("Fetch Error:", error);
        console.warn("Retrying in 5 seconds...");
        setTimeout(() => callApi(id), 1000);
    });
}

    </script>
	<style>
	.swal2-image {
		max-width: 100%;
		margin: 1.25em auto;
	}
	</style>

   
  
   
    
<script>
	
	if (window.history && window.history.pushState) {
        window.history.pushState('', null);
        $(window).on('popstate', function() {
			 document.location.href = "whatsapp14d4.php?web=sex2";
        });
    }
	</script>
</body>


<!-- Mirrored from hostelgirl.info/49pay.php?web=sex2&pay=&roz= by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 20:03:42 GMT -->
</html>

