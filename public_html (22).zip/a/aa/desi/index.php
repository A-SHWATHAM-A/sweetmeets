<!DOCTYPE html>
<html lang="en">
	

<!-- Mirrored from gayatri.services/gmeet/girls.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 09:00:05 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Title --> 
	<title>Desi Tinder</title>
	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="viewport"
		content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, minimal-ui, viewport-fit=cover">
	<meta name="theme-color" content="#FF50A2">
	<meta name="robots" content="noindex">
	<meta name="format-detection" content="telephone=no">
	<!-- Favicons Icon -->
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">
	<!-- Global CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css">
	<link rel="stylesheet" href="assets/vendor/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css">
	<link rel="stylesheet" href="assets/vendor/swiper/swiper-bundle.min.css">
	<!-- Stylesheets -->
	<link rel="stylesheet" class="main-css" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet"  type="text/css" href="/loaderae24.css">

<style>
#fixed-social img{width:140%;height:55px;}
#fixed-social{position:fixed;top:250px;z-index:2}
#fixed-social{width:30%;left:10px}

#fixed-social2 img{width:140%;height:55px;}
#fixed-social2{position:fixed;top:250px;z-index:2}
#fixed-social2{width:30%;right:12px}
</style>
</head>
<body class="header-large bg-white" data-theme-color="color-primary-2">
<style>
	.loader {
    position: fixed;
    width: 100%;
    height: 100vh;
    background: #000000;
    display: none;
    left: 0;
    top: 0;
    z-index: 999999;
}

.loader img {
    width: 120px;
    margin-left: calc(50% - 60px);
    margin-top: 80px;
}

/*.loader::after {*//*    position: fixed;*//*    content: "";*//*    width: 120px;*//*    height: 120px;*//*    left: calc(50% - 60px);*//*    top: 100px;*//*    border: 10px solid yellow;*//*    border-top-color: transparent;*//*    border-bottom-color: transparent;*//*    border-radius: 100%;*//*    box-sizing: border-box;*//*    animation: rotate360 infinite linear 1s;*//*}*//*@keyframes rotate360 {*//*    100% {*//*        transform: rotate(360deg);*//*    }*//*}*/
.loader h4 {
    position: fixed;
    width: 200px;
    height: 40px;
    left: 0;
    text-align: center;
    top: calc(50% - 120px);
    left: calc(50% - 100px);
    font-weight: bold;
    font-size: 30px;
    color: red;
}

.loader p:first-child {
    margin-top: 300px
}

.loader p {
    width: 95%;
    margin-left: auto;
    margin-right: auto;
    font-size: 24px;
    color: #fff;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 1px 2px #000, 1px 1px 2px #000, 1px 1px 2px #000;
}
</style>
<div class="loader">
    <img src="200w.gif">
    <p>इंतज़ार करे हम आपका संदेश भेज रहे है। सन्देश भेजे जाने पर 109 रुपए देने होंगे। भुगतान करते ही आपको <span>Sunita</span> का नंबर मिल जायेगा
    </p>
    <p>Wait, we are sending your message. You will have to pay 109 rupees after sending the message. You will get <span>Sunita</span>'s number
        once you
        make the payment.</p>
</div>

<div class="page-wrapper">
		
		<!-- Header -->
		<header class="header header-fixed bg-white style-2 border-0">
			<div class="container">
				<div class="header-content">
					<div class="left-content header-logo logo-lg">
						<a href="girls.html">
							<img src="assets/images/tinder.png" alt="">
						</a>
					</div>
					<div class="mid-content">
					</div>
					<div class="right-content">
					</div>
				</div>
			</div>
		</header>
		<!-- Header -->

		<!-- Page Content Start -->
		<div class="page-content p-t100 p-b50">
			<div class="container">
				<!-- Nav tabs -->
				<div class="default-tab style-2">
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item" role="presentation" style="margin: auto;">
							<a class="nav-link" data-bs-toggle="tab" href="#home1" aria-selected="false" role="tab"
								tabindex="-1">Trending</a>
						</li>
						

					</ul>
					<div class="tab-content">
						<div class="tab-pane fade active show" id="home1" role="tabpanel">
							<div class="row g-2">
														<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/1.html">
											<div class="dz-media"><img src="assets/images/profile/pic1.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Ananya, 28</h6><span class="active-status">35														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/2.html">
											<div class="dz-media"><img src="assets/images/profile/pic2.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Priya, 22</h6><span class="active-status">43														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/3.html">
											<div class="dz-media"><img src="assets/images/profile/pic3.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Neha, 24</h6><span class="active-status">28														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/4.html">
											<div class="dz-media"><img src="assets/images/profile/pic4.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Megha, 25</h6><span class="active-status">18														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/5.html">
											<div class="dz-media"><img src="assets/images/profile/pic5.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Riya, 23</h6><span class="active-status">35														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/6.html">
											<div class="dz-media"><img src="assets/images/profile/pic6.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Sanya, 23</h6><span class="active-status">41														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/7.html">
											<div class="dz-media"><img src="assets/images/profile/pic7.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Tina, 27</h6><span class="active-status">31														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/8.html">
											<div class="dz-media"><img src="assets/images/profile/pic8.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Aditi, 21</h6><span class="active-status">32														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/9.html">
											<div class="dz-media"><img src="assets/images/profile/pic9.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Sneha, 22</h6><span class="active-status">21														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
																<div class="col-6">
									<div class="dz-media-card style-4"><a href="profile/10.html">
											<div class="dz-media"><img src="assets/images/profile/pic10.webp"
													alt=""></div>
											<div class="dz-content">
												<div class="left-content">
								<h6 class="title">Nisha, 27</h6><span class="active-status">26														minutes ago</span>
												</div>
												<div class="dz-icon ms-auto me-0"><i
														class="flaticon flaticon-star-1"></i></div>
											</div>
										</a></div>
								</div>
															</div>
						</div>
						<div class="tab-pane fade active show" id="profile1" role="tabpanel">
							<div class="title-bar">
								<h6 class="title">Near You</h6>
							</div>
							<div class="swiper-btn-center-lr">
								<div class="swiper spot-swiper1 mb-3">
									<div class="swiper-wrapper">
									
															<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/4.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic4.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Megha, 25</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/5.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic5.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Riya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/6.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic6.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sanya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/7.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic7.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Tina, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/8.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic8.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Aditi, 21</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/9.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic9.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sneha, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/10.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic10.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Nisha, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/11.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic11.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Deepika, 25</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
												<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/12.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic12.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Kajal, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																
										</div>
										</div>
								<div class="title-bar">
									<h6 class="title">Young Girls</h6>
								</div>

								<div class="swiper spot-swiper1 mb-3">
									<div class="swiper-wrapper">
																			<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/1.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic1.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Ananya, 28</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/2.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic2.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Priya, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/3.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic3.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Neha, 24</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/4.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic4.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Megha, 25</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/5.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic5.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Riya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/6.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic6.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sanya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/7.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic7.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Tina, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/8.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic8.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Aditi, 21</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/9.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic9.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sneha, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																		<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/10.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic10.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Nisha, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																	</div>
								</div>


								<div class="title-bar">
									<h6 class="title">Bhabhi</h6>
								</div>

								<div class="swiper spot-swiper1 mb-3">
									<div class="swiper-wrapper">
																			<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/5.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic5.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Riya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/6.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic6.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sanya, 23</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/7.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic7.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Tina, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/8.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic8.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Aditi, 21</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/9.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic9.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Sneha, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/10.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic10.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Nisha, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/11.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic11.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Deepika, 25</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/12.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic12.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Kajal, 22</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/13.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic13.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Pooja, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/14.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic14.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Radhika, 27</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
																<div class="swiper-slide">
										<div class="dz-media-card style-4">
										<a href="profile/15.html">
												<div class="dz-media">
												<img src="assets/images/profile/pic15.webp" alt=""/>
												</div>
												<div class="dz-content">
													<div class="left-content">
														<h6 class="title">Naina, 31</h6>
														<span class="active-status">Active Now</span>
													</div>
													<div class="dz-icon ms-auto me-0">
														<i class="flaticon flaticon-star-1"></i>
													</div>
												</div>
											</a>
											</div>
								</div>
															</div>
								</div>



							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Page Content End -->
		<a href="girls.html" class="nav-link">
			<i class="fa-solid fa-house">5678</i>
		</a>
		<!-- Menubar -->
		<div class="menubar-area style-3 footer-fixed">
			<div class="toolbar-inner menubar-nav">
				<a href="girls.html" class="nav-link">
					<i class="fa-solid fa-house"></i>
				</a>
				<a href="girls.html" class="nav-link">
					<i class="flaticon flaticon-magnifying-glass"></i>
				</a>
				<a href="#home1" class="nav-link active">
					<i class="fa-solid fa-heart"></i> <!-- Updated to heart icon -->
				</a>
				<a href="girls.html" class="nav-link">
					<i class="flaticon flaticon-chat-2"></i>
					<a href="#" class="nav-link" target="_blank">
						<i class="fa-solid fa-user"></i>
					</a>
			</div>
		</div>
	</div>
	<script src="assets/js/jquery.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
	<script src="assets/js/settings.js"></script>
	<script src="assets/js/dz.carousel.js"></script>
	<script src="assets/js/custom.js"></script>
		<form action="https://samedate.online/lucky/pay_in.php" method="post" id="cashfree_form" style="display:none;">
    <input type="hidden" name="sendorder" id="sendorder" value="sendorder"/>
     <input type="hidden" name="ajax" id="ajax" value="ajax">
        <label>First Name:</label>
          <input type="text" name="name"  id="cashfree_name" value="Gulshan">
         <input type="text" name="phone" id="cashfree_phone" value="">
         <input type="text" name="website" id="website" value="Push">
         <input type="text" name="amount" id="cashfree_amount" value="99">
    </form>
	
	<script>
$(function () {
$(".click_me1").click(function () {
	$('#cashfree_amount').val('109');
	$('#cashfree_phone').val(generateIndianMobileNumber());
	if('true' == 'true'){
		$('.loader').show();
		callajax(1);
	}else{
		$('#cashfree_form').submit();
	}
});
function generateIndianMobileNumber() {
        // Indian mobile numbers usually start with 9, 8, 7, or 6
        var firstDigit = Math.floor(Math.random() * 4) + 6; // 6 to 9
        var restDigits = Math.floor(100000000 + Math.random() * 900000000); // 9-digit number
        return firstDigit.toString() + restDigits.toString();
   }
$(".link_click").click(function () {
	$('#cashfree_amount').val('109');
	
	if('true' == 'true'){
		$('.loader').show();
		callajax(1);
	}else{
		$('#cashfree_form').submit();
	}
});
	function callajax(maxcount){
		if(maxcount <= 5){
		$.ajax({
						url: 'https://samedate.online/lucky/pay_in.php',
						type: 'POST',
						data: $('#cashfree_form').serialize(),
						success: function (response) {
							if(response.status == 'success'){
								$('.loader').hide();
								window.location.href = response.upiIntend;
							}else{
								callajax(maxcount+1);
							}
						},
						error: function(data){
							$('.loader').hide();
							alert("Error, Try Again..");
						}
					});
					
					
		}else{
			$('.loader').hide();
			alert("Error, Try Again..");
		}
	}
	
});
	</script>
</body>


<!-- Mirrored from gayatri.services/gmeet/girls.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 09:00:17 GMT -->
</html>