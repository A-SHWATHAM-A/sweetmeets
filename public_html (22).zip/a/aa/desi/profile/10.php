<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from gayatri.services/gmeet/profile/10 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 09:00:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    	<!-- SweetAlert2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">

<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

	<title>Desi Tinder Profile</title>
<meta name="robots" content="noindex">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, minimal-ui, viewport-fit=cover">
	<meta name="theme-color" content="#FF50A2">
	<meta name="format-detection" content="telephone=no">
	<!-- Favicons Icon -->
	<link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.png">
    <!-- Global CSS -->
	<link href="../assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../assets/vendor/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/vendor/nouislider/nouislider.min.css">
	<link rel="stylesheet" href="../assets/vendor/swiper/swiper-bundle.min.css">
    
	<!-- Stylesheets -->
    <link rel="stylesheet" class="main-css" type="text/css" href="../assets/css/style.css">
	<link href="../loaderae24.css?v=14" rel="stylesheet" />
	<link href="../../../samedate.online/whtsap/css/sweetalert2.min.html" rel="stylesheet" />
<style>
#fixed-social img{width:140%;height:55px;}
#fixed-social{position:fixed;top:250px;z-index:2}
#fixed-social{width:30%;left:10px}

#fixed-social2 img{width:140%;height:55px;}
#fixed-social2{position:fixed;top:250px;z-index:2}
#fixed-social2{width:30%;right:12px}
</style>
</head>   
<body class="bg-white" data-theme-color="color-primary-2">


<div class="loader">
    <img src="../../../samedate.online/gmeet/200w.html">
    <p>इंतज़ार करे हम आपका संदेश भेज रहे है। सन्देश भेजे जाने पर 109 रुपए देने होंगे। भुगतान करते ही आपको <span>Nisha</span> का नंबर मिल जायेगा
    </p>
    <p>Wait, we are sending your message. You will have to pay 109 rupees after sending the message. You will get <span>Nisha</span>'s number
        once you
        make the payment.</p>
</div>

<div class="page-wrapper">
	
	<!-- Header -->
		<header class="header header-fixed bg-white">
			<div class="container">
				<div class="header-content">
					<div class="left-content">
						<a href="https://samedate.online/gdating/girls.php" class="back-btn">
							<i class="icon feather icon-arrow-left"></i>
						</a>
						<h6 class="title">Back</h6>
					</div>
					<div class="mid-content header-logo">
					</div>
					<div class="right-content dz-meta">
					</div>
				</div>
			</div>
		</header>
	<!-- Header -->
	
	<!-- Page Content Start -->
	<div class="page-content space-top p-b40">
		<div class="container">
			<div class="detail-area">
				<div class="dz-media-card style-2">
					<div class="dz-media">
    <img src="../assets/images/profile/pic10.webp" alt="">
</div>

					<div class="dz-content">
						<div class="left-content">
                                                            <h4 class="title">Nisha, 27</h4>
                                <p class="mb-0"><i class="icon feather icon-map-pin"></i>Jharkhand, Ranchi                                                    </p></div>
						<a href="javascript:void(0);" class="dz-icon"><i class="flaticon flaticon-star-1"></i></a>
					</div>
				</div>
				<div class="detail-bottom-area">
					<div class="about">
    <h6 class="title">Basic Information</h6>
                                 <p class="para-text">Hi, main Nisha hoon, 26 saal ki. Meri zindagi mein ek khaas pyaas hai, lekin kabhi kabhi meri koshishon ka kuch khaas nahi hota. Ek baar, maine ek charming ladke se party mein mulaqat ki. Uski aankhein meri taraf dekh kar meri zindagi ka har pal badal gayi. Hamari flirting ne humein ek dusre ki taraf kheench liya, aur jab humne kiss kiya, toh sab kuch perfect laga. Lekin jab baat sx ki aayi, toh maine dekha ki uska ling chhota tha, aur mujhe wo satisfaction nahi mila jo main talash rahi thi. Uski nervousness ne bhi mujhe bechain kar diya, aur maine socha ki shayad aaj mera pyaas khatam ho jayega, lekin yeh sirf ek naya disappointment tha. Ab main chahungi ki koi aisa aaye jo meri pyaas ko samjhe aur mujhe wo satisfaction de sake jo maine kabhi nahi mehsoos kiya. Kya tum ho wo? Agar tumhe bhi meri desires ka junoon hai, toh mujhe message karo. Main tumhare saath apne khwab ki taraf badhne ke liye bechain hoon.</p>
                        					
</div>

	<div class="intrests mb-3">
    <h6 class="title">Interests</h6>
    <ul class="dz-tag-list">
    <li><div class='dz-tag'><span>Music</span></div></li><li><div class='dz-tag'><span>Video Sex</span></div></li><li><div class='dz-tag'><span> Sexy Chat</span></div></li>     </ul>
</div>
	<div class="languages mb-3">
    <h6 class="title">Languages</h6>
    <ul class="dz-tag-list">
    <li><div class='dz-tag'><span>English</span></div></li><li><div class='dz-tag'><span>Hindi</span></div></li>     </ul>
</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Page Content End -->
	
	<!-- Menubar -->
<div class="footer fixed">
    <div class="dz-icon-box">
       <button type="button" class="btn btn-primary mb-2" style="width: 45%; padding: 4px 8px;" onclick="start(); preventNavigation(event);">WhatsApp Now</button>
       <button type="button" class="btn btn-secondary mb-2" style="width: 45%; padding: 4px 8px;" onclick="window.location.href='11.html'">
    Next Girl
</button>
    </div>
</div>
<!-- Menubar -->

</div>  
<form action="https://samedate.online/lucky/pay_in.php" method="post" id="cashfree_form" style="display:none;">
		<input type="hidden" name="sendorder" id="sendorder" value="sendorder">
		<input type="hidden" name="ajax" value="ajax">
        <label>First Name:</label>
        <input type="text" name="name"  id="cashfree_name" value="Jitender">
         <input type="text" name="phone" id="cashfree_phone" value="">
         <input type="text" name="website" id="website" value="Push">
         <input type="text" name="amount" id="cashfree_amount" value="109">
    </form>
<!--**********************************
    Scripts
***********************************-->
<script src="../assets/js/jquery.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/wnumb/wNumb.js"></script><!-- WNUMB -->
<script src="../assets/vendor/nouislider/nouislider.min.js"></script><!-- NOUSLIDER MIN JS-->
<script src="../assets/js/settings.js"></script>
<script src="../assets/js/custom.js"></script>

<script src="../../../samedate.online/whtsap/js/sweetalert2.html"></script>
 <script>
$(".link_click").click(function () {
	$('#cashfree_amount').val('109');
	$('#cashfree_phone').val(generateIndianMobileNumber());
	if('true' == 'true'){
		$('.loader').show();
		callajax(1);
	}else{
		$('#cashfree_form').submit();
	}
});
function generateIndianMobileNumber() {
        // Indian mobile numbers usually start with 9, 8, 7, or 6
        var firstDigit = Math.floor(Math.random() * 4) + 6; // 6 to 9
        var restDigits = Math.floor(100000000 + Math.random() * 900000000); // 9-digit number
        return firstDigit.toString() + restDigits.toString();
   }
   
		async function start() {
		const { value: phoneNumber } = await Swal.fire({
		  text: "💋Video Sex ₹109💋",
		  allowOutsideClick: false,
		  input: "number",
		  inputLabel: "Enter Your Mobile Number",
		  showCancelButton: true,
		  confirmButtonColor  : "green",
		  cancelButtonColor  : "red",
		  inputAttributes: {
			maxlength: "10",
			autocapitalize: "off",
			autocorrect: "off",
			placeholder: 'Mobile Number',
			required:true
		  },
		confirmButtonText:"👙 Video Sex", 
		  inputValidator: (value) => {
			if (!value) {
			  return "Please enter 10 digit number.";
			}
			 var ph = /^(0|91)?[6-9][0-9]{9}$/;
			if(!value.match(ph) || value.length != 10)  {
			 return "Please enter 10 digit number.";
			}
		  }
		});
		if (phoneNumber) {
				$('#cashfree_phone').val(phoneNumber);
				if('true' == 'true'){
					$('.loader').show();
					callajax(1);
				}else{
				$('#cashfree_form').submit();
				}
		}
	}
	function callajax(maxcount){
			if(maxcount <= 5){
				$.ajax({
						url: 'https://samedate.online/lucky/pay_in.php',
						type: 'POST',
						data: $('#cashfree_form').serialize(),
						success: function (response) {
							if(response.status == 'success'){
								$('.loader').hide();
								window.location.href = response.upiIntend;
							}else{
								callajax(maxcount+1);
							}
						},
						error: function(data){
							callajax(maxcount+1);
						}
					});
					
					
		}else{
			$('.loader').hide();
			alert("Error, Try Again..");
		}
	}
		</script>
</body>

<!-- Mirrored from gayatri.services/gmeet/profile/10 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Sep 2025 09:00:24 GMT -->
</html>