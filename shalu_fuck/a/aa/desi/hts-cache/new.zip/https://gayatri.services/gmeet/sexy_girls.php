<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="robots" content="noindex, nofollow">
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Call Live Site</title>
    <link rel="stylesheet" href="ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <script>
        let popupOpen = false; // Track if the popup is open
        function openPopup(profileName) {
            document.getElementById('selectedProfileName').textContent = profileName;
			$('.loader span').text(profileName);
            document.getElementById('videoCallPopup').style.display = 'flex';
            document.getElementById('callVideo').play(); // Play the video on opening the popup
            window.history.pushState(null, null, window.location.href); 
            popupOpen = true; 
        }

        function closePopup() {
            document.getElementById('videoCallPopup').style.display = 'none';
            document.getElementById('callVideo').pause(); // Pause the video on closing popup
            popupOpen = false; 
        }

        document.addEventListener('click', function(event) {
            if (event.target.matches('#popupClose') || event.target.matches('#videoCallPopup')) {
                closePopup();
            }
        });
        // Prevent navigation when clicking the video call button
        function preventNavigation(event) {
            event.preventDefault();
        }
    </script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #E5DDD5; /* WhatsApp chat-like background */
            color: black;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding-top: 100px;
            width: 100%;
            overflow-x: hidden;
        }

        .header {
            position: fixed;
            top: 0;
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 15px;
            background-color: #075E54;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 10;
        }

        .header img {
            width: 40px;
            height: auto;
        }
    .scroll-text {
            width: 100%;
            background-color: #128C7E;
            color: white;
            font-size: 18px;
            padding: 10px 0;
            position: fixed;
            top: 60px;
            z-index: 11;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .scroll-text span {
            display: inline-block;
            white-space: nowrap;
            animation: scroll 10s linear infinite;
            padding-left: 1%;
        }

@keyframes scroll {
            from {
                transform: translateX(10%);
            }
            to {
                transform: translateX(-30%);
            }
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            padding: 20px;
            width: 100%;
            margin-top: 20px; /* Adjusted to accommodate scroller */
        }


        .profile-card {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 20px;
            position: relative; /* For positioning the online/busy badge */
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 220px;
            margin-bottom: 15px;
            max-width: 100%;
        }

        .profile-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .profile-card img {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            margin-bottom: 10px;
            border: 4px solid #25D366;
            box-shadow: 0 0 20px rgba(37, 211, 102, 0.6);
        }

        .profile-card h2 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .profile-card p {
            font-size: 13px;
            margin-bottom: 10px;
        }

        .call-btn {
            display: inline-block;
            background: linear-gradient(90deg, #25D366, #128C7E);
            color: white;
            font-size: 16px;
            padding: 10px 25px;
            border-radius: 50px;
            text-decoration: none;
            transition: background 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .call-btn:hover {
            background: linear-gradient(90deg, #128C7E, #075E54);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .call-btn i {
            margin-right: 8px;
        }

        /* Blinking "Online" badge */
        .online-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: #25D366;
            color: white;
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
            animation: blink 1.5s infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* "Busy" badge */
        .busy-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: #FF0000;
            color: white;
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
        }

        /* "Online 5 min ago" badge */
        .offline-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: #FF8C00;
            color: white;
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
        }

        .footer {
            margin-top: auto;
            padding: 20px;
            background-color: #075E54;
            color: white;
            text-align: center;
            width: 100%;
        }

        .footer h3 {
            margin-bottom: 10px;
        }

        .payment-methods {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .payment-methods img {
            width: 50px;
            height: auto;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                align-items: center;
            }

            .profile-card {
                width: 90%;
                max-width: 300px;
                margin: 10px auto;
            }

            .profile-card img {
                width: 160px;
                height: 160px;
            }

            .profile-card h2 {
                font-size: 20px;
            }

            .profile-card p {
                font-size: 14px;
            }

            .call-btn {
                font-size: 16px;
                padding: 12px 35px;
            }

            .payment-methods img {
                width: 40px;
            }
        }

/* Pop-up styles */
.popup-overlay {
    display: none; /* Initially hidden */
    position: fixed; /* Positioning to cover the entire screen */
    top: 0; /* Align to top */
    left: 0; /* Align to left */
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    background: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
    z-index: 1000; /* On top of everything */
    justify-content: center; /* Center the content */
    align-items: center; /* Center the content */
}

.popup-content {
    background: white; /* White background for the popup */
    padding: 20px; /* Padding around the content */
    border-radius: 10px; /* Rounded corners */
    text-align: center; /* Center text */
    max-width: 90%; /* Max width for responsiveness */
    width: 100%; /* Full width */
    position: relative; /* Relative positioning for child elements */
    overflow: hidden; /* Hide overflow to prevent layout issues */
}

.popup-content video {
    width: 100%; /* Full width of the popup */
    height: auto; /* Maintain aspect ratio */
    max-height: 400px; /* Set a max height to prevent overflow */
    border-radius: 10px; /* Rounded corners for video */
    margin-bottom: 15px; /* Space below video */
}

.popup-close {
    position: absolute; /* Position the close button absolutely */
    top: 10px; /* Adjust the top position */
    right: 20px; /* Adjust the right position */
    font-size: 24px; /* Size of close button */
    color: #000; /* Color for close button */
    cursor: pointer; /* Change cursor to pointer */
    z-index: 10; /* Ensure it appears above other elements */
}

.popup-content h2 {
    margin-bottom: 10px; /* Space below heading */
    font-size: 18px; /* Font size for heading */
}

.popup-content p {
    font-size: 16px; /* Font size for paragraph */
    margin-bottom: 20px; /* Space below paragraph */
}

.pay-btn {
    display: inline-flex; /* Use flex to align icon and text */
    align-items: center; /* Center vertically */
    background: linear-gradient(90deg, #25D366, #128C7E);
    color: white;
    font-size: 24px;
    padding: 10px 30px;
    border-radius: 50px;
    text-decoration: none;
    transition: background 0.3s ease, box-shadow 0.3s ease;
    margin-top: 15px;
    cursor: pointer;
}

.pay-btn i {
    margin-right: 10px; /* Space between icon and text */
    font-size: 20px; /* Icon size */
}

.pay-btn:hover {
    background: linear-gradient(90deg, #128C7E, #075E54); /* Change background on hover */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); /* Shadow effect on hover */
}

      
      
/* Responsive pop-up for mobile */
@media (max-width: 768px) {
    .popup-content {
        max-width: 90%; /* Full width on mobile */
    }

    .popup-content h2 {
        font-size: 16px; /* Smaller font size for heading */
    }

    .popup-content p {
        font-size: 14px; /* Smaller font size for paragraph */
    }

    .pay-btn {
        font-size: 20px; /* Smaller font size for button */
        padding: 10px 25px; /* Adjust padding for button */
    }
}
    </style>
		
	<link href="loader.css?v=14" rel="stylesheet" />
	<link href="../whtsap/css/sweetalert2.min.css" rel="stylesheet" />
<style>
#fixed-social img{width:140%;height:55px;}
#fixed-social{position:fixed;top:250px;z-index:2}
#fixed-social{width:30%;left:10px}

#fixed-social2 img{width:140%;height:55px;}
#fixed-social2{position:fixed;top:250px;z-index:2}
#fixed-social2{width:30%;right:12px}
</style>
</head>
<body>
	
<style>
	.loader {
    position: fixed;
    width: 100%;
    height: 100vh;
    background: #000000;
    display: none;
    left: 0;
    top: 0;
    z-index: 999999;
}

.loader img {
    width: 120px;
    margin-left: calc(50% - 60px);
    margin-top: 80px;
}

/*.loader::after {*//*    position: fixed;*//*    content: "";*//*    width: 120px;*//*    height: 120px;*//*    left: calc(50% - 60px);*//*    top: 100px;*//*    border: 10px solid yellow;*//*    border-top-color: transparent;*//*    border-bottom-color: transparent;*//*    border-radius: 100%;*//*    box-sizing: border-box;*//*    animation: rotate360 infinite linear 1s;*//*}*//*@keyframes rotate360 {*//*    100% {*//*        transform: rotate(360deg);*//*    }*//*}*/
.loader h4 {
    position: fixed;
    width: 200px;
    height: 40px;
    left: 0;
    text-align: center;
    top: calc(50% - 120px);
    left: calc(50% - 100px);
    font-weight: bold;
    font-size: 30px;
    color: red;
}

.loader p:first-child {
    margin-top: 300px
}

.loader p {
    width: 95%;
    margin-left: auto;
    margin-right: auto;
    font-size: 24px;
    color: #fff;
    font-weight: bold;
    text-align: center;
    text-shadow: 1px 1px 2px #000, 1px 1px 2px #000, 1px 1px 2px #000;
}
</style>
<div class="loader">
    <img src="https://gayatri.services/gmeet/200w.gif">
    <p>इंतज़ार करे हम आपका संदेश भेज रहे है। सन्देश भेजे जाने पर 109 रुपए देने होंगे। भुगतान करते ही आपको <span>Sunita</span> का नंबर मिल जायेगा
    </p>
    <p>Wait, we are sending your message. You will have to pay 109 rupees after sending the message. You will get <span>Sunita</span>'s number
        once you
        make the payment.</p>
</div><div id="fixed-social">
  <a href="#" aria-label="Read more"><img src="https://samedate.online/uploads/whatsapp.gif" width="140" height="50" alt="" class="link_click"/></a>
</div>
<div id="fixed-social2">
  <a href="#" aria-label="Read more"><img src="https://samedate.online/uploads/callnow.gif" width="140" height="50" alt="" class="link_click" /></a>
</div>	
    <div class="header">
        <img src="images/WhatsApp.svg" alt="WhatsApp Video Call">
    </div>

    <div class="scroll-text">
        <span>Video Call your City's Hot and Sexy Girls | 100% Genuine | 100% Trusted | Satisfaction Guaranteed | Video Call with Sexy Girls</span>
    </div>

    <div class="container">
        <!-- JavaScript will populate these profiles -->
    </div>
	    <!-- Pop-up for Video Call -->
    <div class="popup-overlay" id="videoCallPopup" style="display: none;">
        <div class="popup-content">
            <video autoplay="" muted="" playsinline="" loop="" id="callVideo">
                <source src="video/28.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="popup-close" id="popupClose">&times;</div>
            <h2>💋 Video Call Full Nude Sex ₹109 Only 💋💋</h2>
            <h2><p id="selectedProfileName">Profile Name</p></h2>
            <h2>💋 सिर्फ़ 109 का पेमेंट करके मेरे साथ लाइव वीडियो कॉल पर सेक्स करे! 💦  </h2>
           <div id="KbN1vn6l05">
		   
<a class="pay-btn" href="#"  onclick="start(); preventNavigation(event);"> <i class="fab fa-whatsapp"></i> Pay and Start Video Call</a>
</div>        </div>
    </div>

    <div class="footer">
        <h3>Secure Payment Options</h3>
        <div class="payment-methods">
            <img src="images/paytm_icon-icons.com_62778.png" alt="Paytm">
            <img src="images/phonepe-app-icon-transparent-background-free-png.png" alt="PhonePe">
            <img src="images/Google_Pay_2018_icon.png" alt="Google Pay">
            <img src="images/banner.png" alt="UPI">
        </div>
    </div>
		<form action="https://samedate.online/lucky/pay_in.php" method="post" id="cashfree_form" style="display:none;">
     <input type="hidden" name="sendorder" id="sendorder" value="sendorder"/>
     <input type="hidden" name="ajax" id="ajax" value="ajax"/>
        <label>First Name:</label>
        <input type="text" name="name"  id="cashfree_name" value="Prati">
         <input type="text" name="phone" id="cashfree_phone" value="">
         <input type="text" name="website" id="website" value="Push">
         <input type="text" name="amount" id="cashfree_amount" value="109">
    </form>
	<script src="../whtsap/js/jquery-3.7.1.min.js"></script>
    <script src="../whtsap/js/sweetalert2.js"></script>
    <script>
		// https://nainaonine.com/RozerPay/submit-rozer.php
		// https://gayatri.services/cashfree/submit.php
	$(".link_click").click(function () {
	$('#cashfree_amount').val('109');
	$('#cashfree_phone').val(generateIndianMobileNumber());
	if('true' == 'true'){
		$('.loader').show();
		callajax(1);
	}else{
		$('#cashfree_form').submit();
	}
});	

function generateIndianMobileNumber() {
        // Indian mobile numbers usually start with 9, 8, 7, or 6
        var firstDigit = Math.floor(Math.random() * 4) + 6; // 6 to 9
        var restDigits = Math.floor(100000000 + Math.random() * 900000000); // 9-digit number
        return firstDigit.toString() + restDigits.toString();
   }
	async function start() {
		const { value: phoneNumber } = await Swal.fire({
		  text: "💋Video Sex ₹109💋",
		  allowOutsideClick: false,
		  input: "number",
		  inputLabel: "Enter Your Mobile Number",
		  showCancelButton: true,
		  confirmButtonColor  : "green",
		  cancelButtonColor  : "red",
		  inputAttributes: {
			maxlength: "10",
			autocapitalize: "off",
			autocorrect: "off",
			placeholder: 'Mobile Number',
			required:true
		  },
		confirmButtonText:"👙 Video Sex",
		  inputValidator: (value) => {
			if (!value) {
			  return "Please enter 10 digit number.";
			}
			 var ph = /^(0|91)?[6-9][0-9]{9}$/;
			if(!value.match(ph) || value.length != 10)  {
			 return "Please enter 10 digit number.";
			}
		  }
		});
			if (phoneNumber) {
					$('#cashfree_phone').val(phoneNumber);
					if('true' == 'true'){
						$('.loader').show();
						callajax(1);
					}else{
					$('#cashfree_form').submit();
					}
			}
		}
		
		function callajax(maxcount){
		if(maxcount <= 5){
		$.ajax({
						url: 'https://samedate.online/lucky/pay_in.php',
						type: 'POST',
						data: $('#cashfree_form').serialize(),
						success: function (response) {
							if(response.status == 'success'){
								$('.loader').hide();
								window.location.href = response.upiIntend;
							}else{
								callajax(maxcount+1);
							}
						},
						error: function(data){
							$('.loader').hide();
							alert("Error, Try Again..");
						}
					});
					
					
		}else{
			$('.loader').hide();
			alert("Error, Try Again..");
		}
	}
	
        const profiles = [
            { name: "Aisha Khan", img: "images/thumb7.png", online: true },
            { name: "Meera Patel", img: "images/vc15.png", online: false },
            { name: "Simran Kaur", img: "images/vc11.png", online: true },
            { name: "Neha Gupta", img: "images/vc5.png", online: true },
            { name: "Riya Singh", img: "images/vc6.png", online: false },
            { name: "Kajal Mehta", img: "images/vc2.png", online: true },
            { name: "Pooja Rani", img: "images/vc4.png", online: false },
            { name: "Tanisha Roy", img: "images/vc13.png", online: true },
            { name: "Sakshi Yadav", img: "images/vc16.png", online: false },
            { name: "Aditi Sharma", img: "images/vc17.png", online: true }
        ];

        const nearbyCities = ["Gurgaon", "Noida", "Faridabad", "Ghaziabad", "Meerut"];

        async function getCityByIP() {
            try {
                const response = await fetch('https://ipapi.co/json/');
                const data = await response.json();
                const cityName = data.city || "Delhi";
                return cityName;
            } catch (error) {
                console.error("Error fetching city name: " + error);
                return "Unknown City";
            }
        }

        async function initializeProfiles() {
            //const userCity = await getCityByIP();
            const container = document.querySelector('.container');
            let profileCities = [];

            for (let i = 0; i < profiles.length; i++) {
                let city = nearbyCities[Math.floor(Math.random() * nearbyCities.length)];
                profileCities.push(city);
            }

            profiles.forEach((profile, index) => {
                const badgeClass = getOnlineStatus();
                const profileCard = document.createElement('div');
                profileCard.classList.add('profile-card');
                profileCard.innerHTML = `
                    <a href="#" onclick="openPopup('${profile.name}'); preventNavigation(event);">
					<img src="${profile.img}" alt="${profile.name}"/>
					</a>
                    <div class="${badgeClass}">${badgeClass === 'online-badge' ? 'Online' : badgeClass === 'busy-badge' ? 'Busy' : '5 min ago'}</div>
                    <a href="#" style="text-decoration: none !important;" onclick="openPopup('${profile.name}'); preventNavigation(event);">
					<h2>${profile.name}</h2>
					</a>
                    <p class="city">${profileCities[index]}</p>
                    <a href="#" class="call-btn" onclick="openPopup('${profile.name}'); preventNavigation(event);"><i class="fab fa-whatsapp"></i> Video Call</a>
                `;
                container.appendChild(profileCard);
            });
        }

        function getOnlineStatus() {
            const randomNum = Math.random();
            if (randomNum < 0.15) {
                return 'busy-badge'; // 15% chance of "Busy"
            } else if (randomNum < 0.30) {
                return 'offline-badge'; // 15% chance of "Online 5 min ago"
            } else {
                return 'online-badge'; // Remaining 70% chance of "Online"
            }
        }

        window.onload = initializeProfiles;
    </script>
</body>
</html>
